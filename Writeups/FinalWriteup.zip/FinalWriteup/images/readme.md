A place to store the images for the writeup. Please feel free to upload to here directly.
